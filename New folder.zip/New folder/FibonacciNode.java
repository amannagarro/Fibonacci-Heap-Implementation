

public class FibonacciNode {	
	int count;
	FibonacciNode leftSibling;
	FibonacciNode rightSibling;
	FibonacciNode parent;
	FibonacciNode child;
	String hashtagValue;
	boolean childCut;
	int degree;
}
